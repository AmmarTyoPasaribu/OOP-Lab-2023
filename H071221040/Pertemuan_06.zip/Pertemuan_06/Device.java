interface Device {
    void move ();
}
